const fs = require('fs')
const chalk = require('chalk')

global.owner = ['62895369161594','6281235411534']
global.bugrup = ['62895369161594']
global.sessionName = 'session'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})

// SILAHKAN SETTING SESUAI PERINTAH //